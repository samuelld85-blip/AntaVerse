const source = (id, title, publisher, url, isPrimarySource = true) => ({
  id,
  title,
  publisher,
  url,
  isPrimarySource,
});

const APPLE_MAC = source(
  "apple-macos-list-pack",
  "Identifier la version de macOS installée sur votre Mac",
  "Apple",
  "https://support.apple.com/fr-fr/109033",
);
const APPLE_IOS = source(
  "apple-ios-releases-pack",
  "Apple security releases",
  "Apple",
  "https://support.apple.com/en-us/100100",
);
const APPLE_IPHONE = source(
  "apple-identify-iphone-pack",
  "Identify your iPhone model",
  "Apple",
  "https://support.apple.com/en-us/108044",
);
const IETF_HTTP = source(
  "ietf-http-methods-pack",
  "HTTP Semantics — Methods",
  "Internet Engineering Task Force",
  "https://www.rfc-editor.org/rfc/rfc9110.html#name-methods",
);
const MICROSOFT = source(
  "microsoft-windows-history-pack",
  "Windows evolution",
  "Microsoft",
  "https://news.microsoft.com/announcement/windows-evolution/",
);
const UBUNTU = source(
  "ubuntu-releases-pack",
  "Ubuntu releases",
  "Canonical",
  "https://releases.ubuntu.com/",
  true,
);
const BLUETOOTH = source(
  "bluetooth-core-spec-pack",
  "Core Specifications",
  "Bluetooth SIG",
  "https://www.bluetooth.com/specifications/specs/",
  true,
);
const DEBIAN = source(
  "debian-releases-pack",
  "Debian releases",
  "Debian Project",
  "https://www.debian.org/releases/",
  true,
);
const ORACLE_JAVA = source(
  "oracle-java-history-pack",
  "Java SE versions history",
  "Oracle",
  "https://www.oracle.com/java/technologies/javase/jdk-relnotes-index.html",
  true,
);
const PYTHON = source(
  "python-downloads-pack",
  "Python releases",
  "Python Software Foundation",
  "https://www.python.org/downloads/",
  true,
);
const IEEE_WIFI = source(
  "ieee-80211-pack",
  "IEEE 802.11 Wireless LANs",
  "IEEE",
  "https://www.ieee802.org/11/",
  true,
);
const INTEL = source(
  "intel-processors-history-pack",
  "A history of Intel processors",
  "Intel",
  "https://www.intel.com/content/www/us/en/history/museum-story-of-intel-4004.html",
  true,
);
const POSIX = source(
  "posix-signals-pack",
  "Signal Concepts",
  "The Open Group",
  "https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/signal.h.html",
  true,
);
const IANA_PORTS = source(
  "iana-service-names-pack",
  "Service Name and Transport Protocol Port Number Registry",
  "Internet Assigned Numbers Authority",
  "https://www.iana.org/assignments/service-names-port-numbers/service-names-port-numbers.xhtml",
  true,
);
const USB = source(
  "usb-specifications-pack",
  "USB specifications",
  "USB Implementers Forum",
  "https://www.usb.org/documents",
  true,
);
const W3C_HTML = source(
  "w3c-html-elements-pack",
  "HTML elements",
  "World Wide Web Consortium",
  "https://html.spec.whatwg.org/multipage/indices.html#elements-3",
  false,
);

const q = (spec) => ({
  themeId: "technology",
  qualificationRule:
    spec.qualificationRule ??
    "Sont retenues les neuf entrées du périmètre et de la période indiqués dans la question.",
  explanation:
    spec.explanation ?? "La liste suit l’ordre numérique ou chronologique de la source citée.",
  ...spec,
});

export const questions = [
  q({
    id: "easy-neuf-methodes-http",
    subthemeId: "technology:software",
    difficultyLevel: 1,
    shortTitle: "Méthodes HTTP",
    questionText:
      "Quelles sont les neuf méthodes HTTP enregistrées par l’IANA et définies par les RFC de référence ?",
    answers: ["GET", "HEAD", "POST", "PUT", "DELETE", "CONNECT", "OPTIONS", "TRACE", "PATCH"],
    sources: [IETF_HTTP],
  }),
  q({
    id: "easy-neuf-windows-jusqua-xp",
    subthemeId: "technology:operating-systems",
    difficultyLevel: 1,
    shortTitle: "Windows historique",
    questionText:
      "Quelles sont ces neuf grandes versions de Windows sorties de Windows 1.0 à Windows XP ?",
    answers: [
      "Windows 1.0",
      "Windows 2.0",
      "Windows 3.0",
      "Windows 3.1",
      "Windows 95",
      "Windows 98",
      "Windows Me",
      "Windows 2000",
      "Windows XP",
    ],
    sources: [MICROSOFT],
  }),
  q({
    id: "easy-neuf-premiers-ios",
    subthemeId: "technology:operating-systems",
    difficultyLevel: 1,
    shortTitle: "Premiers iOS",
    questionText:
      "Quels sont les neuf premiers systèmes mobiles majeurs de l’iPhone, d’iPhone OS 1 à iOS 9 ?",
    answers: [
      "iPhone OS 1",
      "iPhone OS 2",
      "iPhone OS 3",
      "iOS 4",
      "iOS 5",
      "iOS 6",
      "iOS 7",
      "iOS 8",
      "iOS 9",
    ],
    sources: [APPLE_IOS],
  }),
  q({
    id: "easy-neuf-premiers-iphone",
    subthemeId: "technology:devices",
    difficultyLevel: 1,
    shortTitle: "Premiers iPhone",
    questionText:
      "Quels sont les neuf premiers modèles d’iPhone commercialisés, du modèle original à l’iPhone 6 ?",
    answers: [
      "iPhone",
      "iPhone 3G",
      "iPhone 3GS",
      "iPhone 4",
      "iPhone 4s",
      "iPhone 5",
      "iPhone 5c",
      "iPhone 5s",
      "iPhone 6",
    ],
    sources: [APPLE_IPHONE],
    exclusionNotes:
      "L’iPhone 6 Plus, lancé en même temps, n’est pas inclus car la borne demandée est l’iPhone 6.",
  }),
  q({
    id: "easy-neuf-premieres-ubuntu",
    subthemeId: "technology:operating-systems",
    difficultyLevel: 1,
    shortTitle: "Ubuntu historique",
    questionText:
      "Quelles sont les neuf premières versions semestrielles d’Ubuntu, de 4.10 à 8.10 ?",
    answers: [
      "Ubuntu 4.10",
      "Ubuntu 5.04",
      "Ubuntu 5.10",
      "Ubuntu 6.06 LTS",
      "Ubuntu 6.10",
      "Ubuntu 7.04",
      "Ubuntu 7.10",
      "Ubuntu 8.04 LTS",
      "Ubuntu 8.10",
    ],
    sources: [UBUNTU],
  }),
  q({
    id: "easy-neuf-bluetooth-jusqua-42",
    subthemeId: "technology:telecommunications",
    difficultyLevel: 1,
    shortTitle: "Bluetooth",
    questionText: "Quelles sont les neuf versions principales de Bluetooth de 1.0 à 4.2 ?",
    answers: [
      "Bluetooth 1.0",
      "Bluetooth 1.1",
      "Bluetooth 1.2",
      "Bluetooth 2.0 + EDR",
      "Bluetooth 2.1 + EDR",
      "Bluetooth 3.0 + HS",
      "Bluetooth 4.0",
      "Bluetooth 4.1",
      "Bluetooth 4.2",
    ],
    sources: [BLUETOOTH],
  }),

  q({
    id: "medium-neuf-premieres-debian",
    subthemeId: "technology:operating-systems",
    difficultyLevel: 2,
    shortTitle: "Debian historique",
    questionText:
      "Quels sont les noms de code des neuf premières versions stables de Debian, de 1.1 à 5.0 ?",
    answers: ["Buzz", "Rex", "Bo", "Hamm", "Slink", "Potato", "Woody", "Sarge", "Etch"],
    sources: [DEBIAN],
    exclusionNotes:
      "Debian 1.0 n’a jamais été publiée officiellement ; la série commence donc à 1.1 Buzz.",
  }),
  q({
    id: "medium-neuf-ubuntu-lts",
    subthemeId: "technology:operating-systems",
    difficultyLevel: 2,
    shortTitle: "Ubuntu LTS",
    questionText: "Quelles sont les neuf versions LTS d’Ubuntu de 6.06 à 22.04 ?",
    answers: [
      "Ubuntu 6.06 LTS",
      "Ubuntu 8.04 LTS",
      "Ubuntu 10.04 LTS",
      "Ubuntu 12.04 LTS",
      "Ubuntu 14.04 LTS",
      "Ubuntu 16.04 LTS",
      "Ubuntu 18.04 LTS",
      "Ubuntu 20.04 LTS",
      "Ubuntu 22.04 LTS",
    ],
    sources: [UBUNTU],
  }),
  q({
    id: "medium-neuf-java-jusqua-8",
    subthemeId: "technology:software",
    difficultyLevel: 2,
    shortTitle: "Java historique",
    questionText: "Quelles sont les neuf versions majeures de Java, de JDK 1.0 à Java SE 8 ?",
    answers: [
      "JDK 1.0",
      "JDK 1.1",
      "J2SE 1.2",
      "J2SE 1.3",
      "J2SE 1.4",
      "J2SE 5.0",
      "Java SE 6",
      "Java SE 7",
      "Java SE 8",
    ],
    sources: [ORACLE_JAVA],
  }),
  q({
    id: "medium-neuf-python-3-0-a-3-8",
    subthemeId: "technology:software",
    difficultyLevel: 2,
    shortTitle: "Python 3",
    questionText: "Quelles sont les neuf premières branches mineures de Python 3, de 3.0 à 3.8 ?",
    answers: [
      "Python 3.0",
      "Python 3.1",
      "Python 3.2",
      "Python 3.3",
      "Python 3.4",
      "Python 3.5",
      "Python 3.6",
      "Python 3.7",
      "Python 3.8",
    ],
    sources: [PYTHON],
  }),
  q({
    id: "medium-neuf-wifi-lettres",
    subthemeId: "technology:telecommunications",
    difficultyLevel: 2,
    shortTitle: "Normes Wi-Fi",
    questionText: "Quelles sont ces neuf extensions IEEE 802.11 publiées de 1999 à 2009 ?",
    answers: [
      "802.11a",
      "802.11b",
      "802.11d",
      "802.11e",
      "802.11g",
      "802.11h",
      "802.11i",
      "802.11j",
      "802.11n",
    ],
    sources: [IEEE_WIFI],
  }),
  q({
    id: "medium-neuf-processeurs-intel",
    subthemeId: "technology:inventions",
    difficultyLevel: 2,
    shortTitle: "Microprocesseurs Intel",
    questionText: "Quels sont ces neuf microprocesseurs historiques d’Intel, du 4004 au Pentium ?",
    answers: [
      "Intel 4004",
      "Intel 8008",
      "Intel 8080",
      "Intel 8086",
      "Intel 8088",
      "Intel 80286",
      "Intel 80386",
      "Intel 80486",
      "Intel Pentium",
    ],
    sources: [INTEL],
  }),

  q({
    id: "hard-signaux-posix-1-a-9",
    subthemeId: "technology:operating-systems",
    difficultyLevel: 3,
    shortTitle: "Signaux POSIX",
    questionText: "Quels sont les noms usuels des signaux Unix numérotés de 1 à 9 sur Linux ?",
    answers: [
      "SIGHUP",
      "SIGINT",
      "SIGQUIT",
      "SIGILL",
      "SIGTRAP",
      "SIGABRT",
      "SIGBUS",
      "SIGFPE",
      "SIGKILL",
    ],
    sources: [POSIX],
  }),
  q({
    id: "hard-ports-bien-connus-20-a-80",
    subthemeId: "technology:telecommunications",
    difficultyLevel: 3,
    shortTitle: "Ports réseau",
    questionText:
      "Quels services correspondent à ces neuf ports bien connus : 20, 21, 22, 23, 25, 53, 67, 69 et 80 ?",
    answers: ["FTP-data", "FTP", "SSH", "Telnet", "SMTP", "DNS", "DHCP", "TFTP", "HTTP"],
    sources: [IANA_PORTS],
    qualificationRule:
      "Sont retenus les noms de service usuels associés par l’IANA aux neuf numéros explicitement cités.",
  }),
  q({
    id: "hard-neuf-macos-classiques",
    subthemeId: "technology:operating-systems",
    difficultyLevel: 3,
    shortTitle: "Mac OS classique",
    questionText: "Quels sont les neuf systèmes Macintosh numérotés de System 1 à Mac OS 9 ?",
    answers: [
      "System 1",
      "System 2",
      "System 3",
      "System 4",
      "System 5",
      "System 6",
      "System 7",
      "Mac OS 8",
      "Mac OS 9",
    ],
    sources: [APPLE_MAC],
  }),
  q({
    id: "hard-neuf-usb-jusqua-32",
    subthemeId: "technology:devices",
    difficultyLevel: 3,
    shortTitle: "Versions USB",
    questionText:
      "Quelles sont ces neuf révisions majeures de la spécification USB, de 1.0 à USB4 2.0 ?",
    answers: [
      "USB 1.0",
      "USB 1.1",
      "USB 2.0",
      "USB 3.0",
      "USB 3.1",
      "USB 3.2",
      "USB4",
      "USB4 2.0",
      "Wireless USB 1.0",
    ],
    sources: [USB],
    qualificationRule:
      "Sont retenues les huit révisions filaires citées et la première spécification Wireless USB publiée par l’USB-IF.",
  }),
  q({
    id: "hard-neuf-elements-html-a",
    subthemeId: "technology:software",
    difficultyLevel: 3,
    shortTitle: "Index HTML",
    questionText:
      "Quels sont les neuf premiers éléments HTML par ordre alphabétique dans l’index de la norme, de a à base ?",
    answers: ["a", "abbr", "address", "area", "article", "aside", "audio", "b", "base"],
    sources: [W3C_HTML],
    qualificationRule:
      "Sont retenues les neuf premières balises de l’index alphabétique de la norme HTML.",
  }),
];
